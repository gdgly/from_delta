# lucky_draw
python tkinter program for lucky draw

1.
the psd file in ps_file folder contains the elements editable for background design, hope it can save your time
ps_file 文件夹中的 psd 文件是用来编辑最终背景图的素材文件，希望借助它可以节省你的时间

2.
you can replace the code related to reading excel by other ways to get the data
数据可以不通过导入表格，把代码中读取表格中的数据替换掉就可以了
